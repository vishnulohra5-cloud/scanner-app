package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    // A4 dimensions at 72 DPI are 595 x 842 pt
    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842

    fun generateIdCardStitchedPdf(
        context: Context,
        frontBitmap: Bitmap?,
        backBitmap: Bitmap?,
        idType: String = "ID Card"
    ): File? {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)

        // Header Title
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 18f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("DIGITIZED IDENTIFICATION CARD", 40f, 60f, textPaint)

        // Subtitle / Disclaimer
        val subPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 10f
            isAntiAlias = true
        }
        canvas.drawText("Type: $idType • On-device digitization utility", 40f, 80f, subPaint)
        canvas.drawText("Generated on ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())}", 40f, 95f, subPaint)

        // Draw Front Side
        val labelPaint = Paint().apply {
            color = Color.parseColor("#1D4ED8")
            textSize = 12f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("FRONT SIDE (300 DPI EQUIVALENT)", 40f, 135f, labelPaint)

        val cardWidth = 515f
        val cardHeight = 310f

        val borderPaint = Paint().apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }

        // Front Card Placement
        val frontRect = RectF(40f, 145f, 40f + cardWidth, 145f + cardHeight)
        if (frontBitmap != null) {
            canvas.drawBitmap(frontBitmap, null, frontRect, null)
            canvas.drawRoundRect(frontRect, 12f, 12f, borderPaint)
        } else {
            canvas.drawRoundRect(frontRect, 12f, 12f, borderPaint)
            canvas.drawText("Front side preview not captured", 80f, 290f, subPaint)
        }

        // Draw Back Side
        canvas.drawText("BACK SIDE (300 DPI EQUIVALENT)", 40f, 490f, labelPaint)
        val backRect = RectF(40f, 500f, 40f + cardWidth, 500f + cardHeight)
        if (backBitmap != null) {
            canvas.drawBitmap(backBitmap, null, backRect, null)
            canvas.drawRoundRect(backRect, 12f, 12f, borderPaint)
        } else {
            canvas.drawRoundRect(backRect, 12f, 12f, borderPaint)
            canvas.drawText("Back side preview not captured", 80f, 650f, subPaint)
        }

        // Footer Disclaimer
        val footerPaint = Paint().apply {
            color = Color.GRAY
            textSize = 8f
            isAntiAlias = true
        }
        canvas.drawText(
            "Privacy Notice: Secure on-device digitization utility • Not affiliated with any government agency.",
            40f,
            820f,
            footerPaint
        )

        document.finishPage(page)

        return try {
            val fileName = "ID_Card_${System.currentTimeMillis()}.pdf"
            val file = File(context.cacheDir, fileName)
            val outputStream = FileOutputStream(file)
            document.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            document.close()
            file
        } catch (e: Exception) {
            document.close()
            null
        }
    }

    fun generateTextOrBarcodePdf(
        context: Context,
        title: String,
        content: String,
        metadata: String
    ): File? {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        canvas.drawColor(Color.WHITE)

        val headerPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText(title, 40f, 60f, headerPaint)

        val metaPaint = Paint().apply {
            color = Color.GRAY
            textSize = 10f
            isAntiAlias = true
        }
        canvas.drawText("Exported via Scanner - All In One • $metadata", 40f, 85f, metaPaint)

        val contentPaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            isAntiAlias = true
        }

        var y = 130f
        val lines = content.chunked(70)
        for (line in lines) {
            canvas.drawText(line, 40f, y, contentPaint)
            y += 18f
            if (y > PAGE_HEIGHT - 60) break
        }

        document.finishPage(page)

        return try {
            val fileName = "Scan_Export_${System.currentTimeMillis()}.pdf"
            val file = File(context.cacheDir, fileName)
            val outputStream = FileOutputStream(file)
            document.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            document.close()
            file
        } catch (e: Exception) {
            document.close()
            null
        }
    }
}
