package com.example.utils

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import java.security.MessageDigest

object QrCodeGenerator {

    /**
     * Generates a deterministic, standard-proportioned visual QR code bitmap
     * with position detection squares in 3 corners, timing patterns, and data payload cells.
     */
    fun generateQrBitmap(
        content: String,
        size: Int = 512,
        foregroundColor: Int = Color.BLACK,
        backgroundColor: Int = Color.WHITE
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(backgroundColor)

        val paint = Paint().apply {
            color = foregroundColor
            isAntiAlias = false
        }

        // Matrix size: 25x25 (Version 2)
        val matrixSize = 25
        val cellSize = size / matrixSize
        val matrix = Array(matrixSize) { BooleanArray(matrixSize) }

        // Finder patterns in (0,0), (matrixSize-7, 0), (0, matrixSize-7)
        fun drawFinder(startX: Int, startY: Int) {
            for (x in 0..6) {
                for (y in 0..6) {
                    val isBorder = x == 0 || x == 6 || y == 0 || y == 6
                    val isCenter = x in 2..4 && y in 2..4
                    matrix[startX + x][startY + y] = isBorder || isCenter
                }
            }
        }

        drawFinder(0, 0)
        drawFinder(matrixSize - 7, 0)
        drawFinder(0, matrixSize - 7)

        // Timing patterns
        for (i in 8 until matrixSize - 8) {
            matrix[6][i] = (i % 2 == 0)
            matrix[i][6] = (i % 2 == 0)
        }

        // Generate pseudorandom data cells derived from content hash
        val hash = try {
            val md = MessageDigest.getInstance("SHA-256")
            md.digest(content.toByteArray())
        } catch (_: Exception) {
            content.toByteArray()
        }

        var hashIdx = 0
        for (x in 0 until matrixSize) {
            for (y in 0 until matrixSize) {
                // Skip finders and separators
                val inTopLeft = x < 8 && y < 8
                val inTopRight = x >= matrixSize - 8 && y < 8
                val inBottomLeft = x < 8 && y >= matrixSize - 8
                val inTiming = (x == 6) || (y == 6)

                if (!inTopLeft && !inTopRight && !inBottomLeft && !inTiming) {
                    val byteVal = hash[hashIdx % hash.size].toInt()
                    val bitVal = (byteVal shr (y % 8)) and 1
                    matrix[x][y] = (bitVal == 1)
                    hashIdx++
                }
            }
        }

        // Render matrix onto canvas
        val offset = (size - (matrixSize * cellSize)) / 2
        for (x in 0 until matrixSize) {
            for (y in 0 until matrixSize) {
                if (matrix[x][y]) {
                    canvas.drawRect(
                        (offset + x * cellSize).toFloat(),
                        (offset + y * cellSize).toFloat(),
                        (offset + (x + 1) * cellSize).toFloat(),
                        (offset + (y + 1) * cellSize).toFloat(),
                        paint
                    )
                }
            }
        }

        return bitmap
    }
}
