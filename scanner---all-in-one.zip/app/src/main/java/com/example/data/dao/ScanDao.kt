package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ScanItem
import com.example.data.model.ScanType
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanDao {

    @Query("SELECT * FROM scans ORDER BY timestamp DESC")
    fun getAllScans(): Flow<List<ScanItem>>

    @Query("SELECT * FROM scans ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentScans(limit: Int): Flow<List<ScanItem>>

    @Query("SELECT * FROM scans WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoriteScans(): Flow<List<ScanItem>>

    @Query("SELECT * FROM scans WHERE type IN (:types) ORDER BY timestamp DESC")
    fun getScansByTypes(types: List<ScanType>): Flow<List<ScanItem>>

    @Query("SELECT * FROM scans WHERE title LIKE '%' || :query || '%' OR payload LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchScans(query: String): Flow<List<ScanItem>>

    @Query("SELECT * FROM scans WHERE id = :id LIMIT 1")
    fun getScanById(id: Long): Flow<ScanItem?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScan(item: ScanItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ScanItem>)

    @Update
    suspend fun updateScan(item: ScanItem)

    @Query("UPDATE scans SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE scans SET note = :note WHERE id = :id")
    suspend fun updateNote(id: Long, note: String)

    @Delete
    suspend fun deleteScan(item: ScanItem)

    @Query("DELETE FROM scans WHERE id = :id")
    suspend fun deleteScanById(id: Long)

    @Query("SELECT COUNT(*) FROM scans")
    suspend fun getCount(): Int
}
