package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scans")
data class ScanItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val type: ScanType,
    val payload: String,
    val formatInfo: String = "",
    val securityStatus: String = "Safe",
    val metaDetail: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val filePath: String? = null,
    val isFavorite: Boolean = false,
    val note: String? = null
)
