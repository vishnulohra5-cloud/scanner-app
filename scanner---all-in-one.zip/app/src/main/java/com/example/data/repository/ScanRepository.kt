package com.example.data.repository

import com.example.data.dao.ScanDao
import com.example.data.model.ScanItem
import com.example.data.model.ScanType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ScanRepository(private val scanDao: ScanDao) {

    val allScans: Flow<List<ScanItem>> = scanDao.getAllScans()
    val recentScans: Flow<List<ScanItem>> = scanDao.getRecentScans(15)
    val favoriteScans: Flow<List<ScanItem>> = scanDao.getFavoriteScans()

    fun getScanById(id: Long): Flow<ScanItem?> = scanDao.getScanById(id)

    fun searchScans(query: String): Flow<List<ScanItem>> = scanDao.searchScans(query)

    fun getScansByCategory(category: String): Flow<List<ScanItem>> {
        return when (category) {
            "Documents" -> scanDao.getScansByTypes(listOf(ScanType.DOCUMENT, ScanType.ID_CARD))
            "QR/Barcode" -> scanDao.getScansByTypes(listOf(ScanType.QR_CODE, ScanType.BARCODE))
            else -> scanDao.getAllScans()
        }
    }

    suspend fun insertScan(item: ScanItem): Long = withContext(Dispatchers.IO) {
        scanDao.insertScan(item)
    }

    suspend fun toggleFavorite(id: Long, currentStatus: Boolean) = withContext(Dispatchers.IO) {
        scanDao.updateFavorite(id, !currentStatus)
    }

    suspend fun updateNote(id: Long, note: String) = withContext(Dispatchers.IO) {
        scanDao.updateNote(id, note)
    }

    suspend fun deleteScanById(id: Long) = withContext(Dispatchers.IO) {
        scanDao.deleteScanById(id)
    }

    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        if (scanDao.getCount() == 0) {
            val sampleItems = listOf(
                ScanItem(
                    title = "Meeting Notes 2025.pdf",
                    type = ScanType.DOCUMENT,
                    payload = "Document scan: Quarterly roadmap review & sprint planning notes.",
                    formatInfo = "PDF 1.7 (A4 Document)",
                    securityStatus = "Clean",
                    metaDetail = "10:24 AM • 1.4 MB • 3 PGS",
                    timestamp = System.currentTimeMillis() - (1000 * 60 * 30), // 30 mins ago
                    isFavorite = true,
                    note = "Review with team tomorrow at standup."
                ),
                ScanItem(
                    title = "WiFi: Office_Guest_5G",
                    type = ScanType.QR_CODE,
                    payload = "WIFI:S:Office_Guest_5G;T:WPA;P:OfficeSecurePass2025;;",
                    formatInfo = "Format: QR_CODE (Version 2, 25x25) ECC: Medium",
                    securityStatus = "Safe Network Verified",
                    metaDetail = "Yesterday • Auto-saved",
                    timestamp = System.currentTimeMillis() - (1000 * 60 * 60 * 24), // yesterday
                    isFavorite = false,
                    note = "Guest lounge access point credentials"
                ),
                ScanItem(
                    title = "Product EAN-13 8901234567890",
                    type = ScanType.BARCODE,
                    payload = "8901234567890",
                    formatInfo = "Format: EAN-13 • Retail Barcode",
                    securityStatus = "Valid GTIN / Checksum Verified",
                    metaDetail = "Sep 28 • Lookup ready",
                    timestamp = System.currentTimeMillis() - (1000 * 60 * 60 * 48),
                    isFavorite = false,
                    note = "Inventory retail stock unit"
                ),
                ScanItem(
                    title = "Annual Report Download",
                    type = ScanType.QR_CODE,
                    payload = "https://docs.workspace.dev/annual-report-2025/download",
                    formatInfo = "Format: QR_CODE (Version 4, 33x33) ECC: Quartile",
                    securityStatus = "Zero threats • SSL Secure TLS 1.3",
                    metaDetail = "Just now • High confidence",
                    timestamp = System.currentTimeMillis() - (1000 * 60 * 5),
                    isFavorite = true,
                    note = "Review report download before 5:00 PM"
                )
            )
            scanDao.insertAll(sampleItems)
        }
    }
}
