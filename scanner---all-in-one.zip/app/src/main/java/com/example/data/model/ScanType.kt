package com.example.data.model

enum class ScanType {
    QR_CODE,
    BARCODE,
    DOCUMENT,
    ID_CARD,
    TEXT_OCR;

    fun displayName(): String = when (this) {
        QR_CODE -> "Network QR"
        BARCODE -> "Retail Barcode"
        DOCUMENT -> "PDF Document"
        ID_CARD -> "ID Card"
        TEXT_OCR -> "Text OCR"
    }
}
