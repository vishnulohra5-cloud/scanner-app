package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ScanItem
import com.example.data.model.ScanType
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BackgroundDarkSecondary
import com.example.ui.theme.BorderAccent
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardGlass
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.glassCard
import com.example.ui.theme.neonGlowCard
import com.example.ui.viewmodel.CameraScannerMode
import com.example.ui.viewmodel.ScannerViewModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

@Composable
fun HomeScreen(
    viewModel: ScannerViewModel,
    onNavigateToCamera: (CameraScannerMode) -> Unit,
    onNavigateToIdCard: () -> Unit,
    onNavigateToGenerate: () -> Unit,
    onNavigateToPdfTools: () -> Unit,
    onNavigateToScanDetail: (ScanItem) -> Unit,
    onNavigateToTab: (String) -> Unit,
    activeTab: String = "home"
) {
    val context = LocalContext.current
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val scans by viewModel.scans.collectAsStateWithLifecycle()
    val clipboardManager = LocalClipboardManager.current

    // Gallery Picker launcher for on-device image scanning
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputImage = InputImage.fromFilePath(context, uri)
                val barcodeScanner = BarcodeScanning.getClient()
                barcodeScanner.process(inputImage)
                    .addOnSuccessListener { barcodes ->
                        if (barcodes.isNotEmpty()) {
                            val barcode = barcodes.first()
                            val raw = barcode.rawValue ?: "Scanned barcode"
                            viewModel.onScanDetected(
                                rawPayload = raw,
                                type = ScanType.QR_CODE,
                                formatName = barcode.format.toString(),
                                onDone = { item -> onNavigateToScanDetail(item) }
                            )
                        } else {
                            // Fallback to text OCR
                            val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                            textRecognizer.process(inputImage)
                                .addOnSuccessListener { visionText ->
                                    if (visionText.text.isNotBlank()) {
                                        viewModel.onScanDetected(
                                            rawPayload = visionText.text,
                                            type = ScanType.TEXT_OCR,
                                            formatName = "OCR_TEXT",
                                            onDone = { item -> onNavigateToScanDetail(item) }
                                        )
                                    } else {
                                        Toast.makeText(context, "No readable code or text found in image", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                .addOnFailureListener {
                                    Toast.makeText(context, "Failed to analyze image", Toast.LENGTH_SHORT).show()
                                }
                        }
                    }
                    .addOnFailureListener {
                        Toast.makeText(context, "Analysis error", Toast.LENGTH_SHORT).show()
                    }
            } catch (e: Exception) {
                Toast.makeText(context, "Could not open image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(bottom = 90.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. TOP BAR
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Squircle App Icon matching unnamed.jpg
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF0D1830), Color(0xFF1E3A8A))
                                )
                            )
                            .border(1.dp, Color(0x6600E5FF), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "App Icon",
                            tint = NeonCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Scanner – All In One",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(SuccessGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ON-DEVICE OCR ENGINE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SuccessGreen,
                                    letterSpacing = 0.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    // Top Action Icons
                    IconButton(
                        onClick = {
                            Toast.makeText(context, "Search active", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = TextSecondary
                        )
                    }

                    IconButton(
                        onClick = {
                            Toast.makeText(context, "No new notifications", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = TextSecondary
                        )
                    }
                }
            }

            // 2. HERO / FAST ACTION CARD ("Ready to Capture")
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .border(
                            1.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0x8000E5FF), Color(0x203B82F6), Color(0x8000E5FF))
                            ),
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { onNavigateToCamera(CameraScannerMode.QR_BARCODE) },
                    colors = CardDefaults.cardColors(containerColor = SurfaceCardGlass),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                // Instant Auto-Detect Pill
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(Color(0x2610B981))
                                        .border(0.8.dp, Color(0x6610B981), RoundedCornerShape(20.dp))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.FlashOn,
                                            contentDescription = null,
                                            tint = SuccessGreen,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Instant Auto-Detect",
                                            color = SuccessGreen,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "Ready to Capture",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Point camera or choose quick workflow below",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = TextSecondary
                                    )
                                )
                            }

                            // Big Camera Action Button
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(ElectricBlue, NeonBlue)
                                        )
                                    )
                                    .shadow(elevation = 8.dp, shape = RoundedCornerShape(16.dp))
                                    .clickable { onNavigateToCamera(CameraScannerMode.QR_BARCODE) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Scan",
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Search Bar inside Hero Card
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = {
                                Text(
                                    text = "Search scans, text, files...",
                                    color = TextMuted,
                                    fontSize = 13.sp
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Filter",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .clip(RoundedCornerShape(14.dp)),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = BackgroundDark,
                                unfocusedContainerColor = BackgroundDark,
                                focusedBorderColor = BorderAccent,
                                unfocusedBorderColor = BorderSubtle,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Filter Chips Row: All, Documents, QR/Barcode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                label = "All",
                                icon = "✦",
                                isSelected = selectedCategory == "All",
                                onClick = { viewModel.setSelectedCategory("All") }
                            )
                            FilterChip(
                                label = "Documents",
                                icon = "📄",
                                isSelected = selectedCategory == "Documents",
                                onClick = { viewModel.setSelectedCategory("Documents") }
                            )
                            FilterChip(
                                label = "QR/Barcode",
                                icon = "🔲",
                                isSelected = selectedCategory == "QR/Barcode",
                                onClick = { viewModel.setSelectedCategory("QR/Barcode") }
                            )
                        }
                    }
                }
            }

            // 3. CORE MODULES SECTION (Hardware Accelerated)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Core Modules",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "Hardware Accelerated",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = NeonCyan,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }

            // 8 CORE MODULES GRID (2 columns x 4 rows)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Row 1: Scan QR Code & Scan Barcode
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ModuleCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.QrCode,
                            title = "Scan QR Code",
                            subtitle = "URLs, Wi-Fi, UPI &\nvCards",
                            badgeText = "Fast",
                            iconColor = NeonCyan,
                            badgeBg = Color(0x3300E5FF),
                            badgeColor = NeonCyan,
                            onClick = { onNavigateToCamera(CameraScannerMode.QR_BARCODE) }
                        )

                        ModuleCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.ViewInAr,
                            title = "Scan Barcode",
                            subtitle = "EAN, UPC, Code-128",
                            badgeText = "Batch Ready",
                            iconColor = BrightCyan,
                            badgeBg = Color(0x3338BDF8),
                            badgeColor = BrightCyan,
                            onClick = { onNavigateToCamera(CameraScannerMode.QR_BARCODE) }
                        )
                    }

                    // Row 2: Document Scanner & ID Card Scanner
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ModuleCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Description,
                            title = "Document Scanner",
                            subtitle = "Auto edge crop & filters",
                            badgeText = "●",
                            iconColor = SuccessGreen,
                            badgeBg = Color(0x2610B981),
                            badgeColor = SuccessGreen,
                            onClick = { onNavigateToCamera(CameraScannerMode.DOCUMENT) }
                        )

                        ModuleCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.CreditCard,
                            title = "ID Card Scanner",
                            subtitle = "Combine front & back",
                            badgeText = "2-Sided",
                            iconColor = NeonCyan,
                            badgeBg = Color(0x3300E5FF),
                            badgeColor = NeonCyan,
                            onClick = onNavigateToIdCard
                        )
                    }

                    // Row 3: OCR Text Extractor & Gallery Scan
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ModuleCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Description,
                            title = "OCR Text Extractor",
                            subtitle = "Instant live copy text",
                            badgeText = "OCR",
                            iconColor = ElectricBlue,
                            badgeBg = Color(0x333B82F6),
                            badgeColor = ElectricBlue,
                            onClick = { onNavigateToCamera(CameraScannerMode.TEXT_OCR) }
                        )

                        ModuleCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Image,
                            title = "Gallery Scan",
                            subtitle = "Import device photos",
                            badgeText = "Batch",
                            iconColor = TextSecondary,
                            badgeBg = Color(0x2694A3B8),
                            badgeColor = TextSecondary,
                            onClick = { galleryLauncher.launch("image/*") }
                        )
                    }

                    // Row 4: Generate Code & PDF Tools & Convert
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ModuleCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.QrCode,
                            title = "Generate Code",
                            subtitle = "QR, Aztec, Barcodes",
                            badgeText = "+",
                            iconColor = BrightCyan,
                            badgeBg = Color(0x3338BDF8),
                            badgeColor = BrightCyan,
                            onClick = onNavigateToGenerate
                        )

                        ModuleCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.PictureAsPdf,
                            title = "PDF Tools & Convert",
                            subtitle = "Compress, password,\ne-sign",
                            badgeText = "Merge / Sign",
                            iconColor = Color(0xFFF87171),
                            badgeBg = Color(0x33EF4444),
                            badgeColor = Color(0xFFF87171),
                            onClick = onNavigateToPdfTools
                        )
                    }
                }
            }

            // 4. RECENT ACTIVITY HEADER
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 4.dp, end = 4.dp, top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Recent Activity",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF1E293B))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${scans.size} new",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onNavigateToTab("history") }
                    ) {
                        Text(
                            text = "View all",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = TextSecondary
                            )
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            // RECENT ACTIVITY ITEMS
            items(scans.take(6), key = { it.id }) { scan ->
                RecentScanRow(
                    item = scan,
                    onClick = { onNavigateToScanDetail(scan) },
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(scan.payload))
                        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    onShare = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, scan.payload)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share Scanned Payload"))
                    },
                    onToggleFavorite = { viewModel.toggleFavorite(scan) },
                    onDelete = { viewModel.deleteScan(scan.id) }
                )
            }
        }

        // BOTTOM NAVIGATION BAR WITH GLOWING CENTER SCAN BUTTON
        BottomNavBar(
            modifier = Modifier.align(Alignment.BottomCenter),
            activeTab = activeTab,
            onTabSelected = onNavigateToTab,
            onCenterScanClick = { onNavigateToCamera(CameraScannerMode.QR_BARCODE) }
        )
    }
}

@Composable
fun FilterChip(
    label: String,
    icon: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bgColor = if (isSelected) NeonBlue else SurfaceElevated
    val textColor = if (isSelected) Color.White else TextSecondary
    val borderColor = if (isSelected) NeonCyan else BorderSubtle

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bgColor)
            .border(0.8.dp, borderColor, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = icon, fontSize = 12.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = textColor,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
fun ModuleCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    badgeText: String,
    iconColor: Color,
    badgeBg: Color,
    badgeColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(118.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                // Icon Box
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF131D33)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Badge Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(badgeBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = badgeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 13.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextMuted,
                        fontSize = 10.5.sp,
                        lineHeight = 13.sp
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun RecentScanRow(
    item: ScanItem,
    onClick: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail / Icon Badge
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        when (item.type) {
                            ScanType.DOCUMENT -> Color(0xFF1E293B)
                            ScanType.QR_CODE -> Color(0xFF112240)
                            ScanType.BARCODE -> Color(0xFF0F2B26)
                            else -> Color(0xFF1E293B)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = when (item.type) {
                            ScanType.DOCUMENT -> Icons.Default.Description
                            ScanType.QR_CODE -> Icons.Default.Wifi
                            ScanType.BARCODE -> Icons.Default.ViewInAr
                            ScanType.ID_CARD -> Icons.Default.CreditCard
                            ScanType.TEXT_OCR -> Icons.Default.Description
                        },
                        contentDescription = null,
                        tint = when (item.type) {
                            ScanType.DOCUMENT -> TextSecondary
                            ScanType.QR_CODE -> BrightCyan
                            ScanType.BARCODE -> SuccessGreen
                            else -> NeonCyan
                        },
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = when (item.type) {
                            ScanType.DOCUMENT -> "3 PGS"
                            ScanType.QR_CODE -> "WIFI"
                            ScanType.BARCODE -> "EAN-13"
                            ScanType.ID_CARD -> "ID"
                            ScanType.TEXT_OCR -> "TXT"
                        },
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (item.type) {
                            ScanType.DOCUMENT -> BrightCyan
                            ScanType.QR_CODE -> BrightCyan
                            ScanType.BARCODE -> SuccessGreen
                            else -> NeonCyan
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Text Info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.type.displayName(),
                        color = when (item.type) {
                            ScanType.DOCUMENT -> BrightCyan
                            ScanType.QR_CODE -> BrightCyan
                            ScanType.BARCODE -> TextSecondary
                            else -> NeonCyan
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = " • ",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                    Text(
                        text = item.metaDetail,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            // Quick Actions: Share or Copy
            IconButton(
                onClick = onShare,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // More Options Dropdown
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "More",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(SurfaceDark)
                ) {
                    DropdownMenuItem(
                        text = { Text(if (item.isFavorite) "Remove Favorite" else "Add to Favorites", color = TextPrimary) },
                        onClick = {
                            showMenu = false
                            onToggleFavorite()
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = if (item.isFavorite) Color.Red else TextSecondary
                            )
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Copy Payload", color = TextPrimary) },
                        onClick = {
                            showMenu = false
                            onCopy()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = TextSecondary)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete Record", color = Color(0xFFEF4444)) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFFEF4444))
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun BottomNavBar(
    modifier: Modifier = Modifier,
    activeTab: String,
    onTabSelected: (String) -> Unit,
    onCenterScanClick: () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        // Bar background
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(SurfaceDark)
                .border(1.dp, BorderSubtle, RoundedCornerShape(32.dp))
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Home Tab
            NavTabItem(
                title = "Home",
                icon = Icons.Default.Home,
                isActive = activeTab == "home",
                onClick = { onTabSelected("home") }
            )

            // History Tab
            NavTabItem(
                title = "History",
                icon = Icons.Default.History,
                isActive = activeTab == "history",
                onClick = { onTabSelected("history") }
            )

            // Center space for floating button
            Spacer(modifier = Modifier.width(56.dp))

            // Favorites Tab
            NavTabItem(
                title = "Favorites",
                icon = Icons.Default.Favorite,
                isActive = activeTab == "favorites",
                onClick = { onTabSelected("favorites") }
            )

            // Settings Tab
            NavTabItem(
                title = "Settings",
                icon = Icons.Default.Settings,
                isActive = activeTab == "settings",
                onClick = { onTabSelected("settings") }
            )
        }

        // Center Floating Glowing Scanner Button matching screenshot
        Box(
            modifier = Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF00F0FF), Color(0xFF1D4ED8), BackgroundDark)
                    )
                )
                .border(2.dp, NeonCyan, CircleShape)
                .clickable(onClick = onCenterScanClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.QrCodeScanner,
                contentDescription = "Scan Now",
                tint = Color.White,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
fun NavTabItem(
    title: String,
    icon: ImageVector,
    isActive: Boolean,
    onClick: () -> Unit
) {
    if (isActive) {
        // Active blue pill
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(NeonBlue)
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    } else {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = TextSecondary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                color = TextSecondary,
                fontSize = 10.sp
            )
        }
    }
}
