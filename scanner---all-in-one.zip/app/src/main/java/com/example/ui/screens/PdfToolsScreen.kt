package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ScannerViewModel
import com.example.utils.PdfGenerator

@Composable
fun PdfToolsScreen(
    viewModel: ScannerViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToIdCard: () -> Unit
) {
    val context = LocalContext.current

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val pdf = PdfGenerator.generateTextOrBarcodePdf(
                context = context,
                title = "Imported Image Document",
                content = "Document generated from photo: ${uri.lastPathSegment ?: "image"}",
                metadata = "PDF Converter Tool"
            )
            if (pdf != null) {
                Toast.makeText(context, "PDF successfully generated!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // TOP BAR
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Text(
                    text = "PDF Tools & Convert",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
            }

            Text(
                text = "Professional Document Utilities",
                color = TextSecondary,
                fontSize = 13.sp
            )

            // TOOL CARDS
            PdfActionCard(
                icon = Icons.Default.Image,
                iconColor = BrightCyan,
                title = "Images to PDF",
                subtitle = "Convert multiple photos or gallery receipts into a single PDF document.",
                onClick = { imagePicker.launch("image/*") }
            )

            PdfActionCard(
                icon = Icons.Default.CreditCard,
                iconColor = NeonCyan,
                title = "ID Card 2-Sided Stitch",
                subtitle = "Combine front and back ID scans into a 300 DPI A4 sheet ready for printing.",
                onClick = onNavigateToIdCard
            )

            PdfActionCard(
                icon = Icons.Default.Compress,
                iconColor = SuccessGreen,
                title = "Compress PDF",
                subtitle = "Reduce PDF file size up to 70% while maintaining crisp document readability.",
                onClick = { Toast.makeText(context, "PDF Compressor ready", Toast.LENGTH_SHORT).show() }
            )

            PdfActionCard(
                icon = Icons.Default.Draw,
                iconColor = ElectricBlue,
                title = "E-Sign Document",
                subtitle = "Draw, save, and attach legally recognized electronic signatures.",
                onClick = { Toast.makeText(context, "E-Sign Tool ready", Toast.LENGTH_SHORT).show() }
            )

            PdfActionCard(
                icon = Icons.Default.Lock,
                iconColor = Color(0xFFF59E0B),
                title = "Password Protect",
                subtitle = "Encrypt sensitive PDF contracts with 256-bit AES encryption.",
                onClick = { Toast.makeText(context, "AES-256 PDF Encryption ready", Toast.LENGTH_SHORT).show() }
            )

            PdfActionCard(
                icon = Icons.Default.MergeType,
                iconColor = Color(0xFFEC4899),
                title = "Merge PDFs",
                subtitle = "Combine separate invoices, scans, and notes into one coherent book.",
                onClick = { Toast.makeText(context, "Select PDF files to merge", Toast.LENGTH_SHORT).show() }
            )
        }
    }
}

@Composable
fun PdfActionCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF131D33)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
