package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Vibrator
import android.os.VibratorManager
import android.os.VibrationEffect
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ScanItem
import com.example.data.model.ScanType
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CameraScannerMode
import com.example.ui.viewmodel.ScannerViewModel
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

@Composable
fun CameraScreen(
    viewModel: ScannerViewModel,
    initialMode: CameraScannerMode = CameraScannerMode.QR_BARCODE,
    onNavigateBack: () -> Unit,
    onNavigateToScanDetail: (ScanItem) -> Unit,
    onNavigateToIdCard: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val cameraMode by viewModel.cameraMode.collectAsStateWithLifecycle()
    val isFlashOn by viewModel.isFlashOn.collectAsStateWithLifecycle()
    val isSoundEnabled by viewModel.isSoundEnabled.collectAsStateWithLifecycle()
    val zoomLevel by viewModel.zoomLevel.collectAsStateWithLifecycle()
    val isBatchMode by viewModel.isBatchMode.collectAsStateWithLifecycle()

    var cameraInstance by remember { mutableStateOf<Camera?>(null) }
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            Toast.makeText(context, "Camera permission is required to scan codes", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.setCameraMode(initialMode)
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Handle zoom changes on cameraInstance
    LaunchedEffect(zoomLevel, cameraInstance) {
        cameraInstance?.cameraControl?.setZoomRatio(zoomLevel)
    }

    // Handle flash toggle
    LaunchedEffect(isFlashOn, cameraInstance) {
        cameraInstance?.cameraControl?.enableTorch(isFlashOn)
    }

    // Gallery Picker for importing photo directly in scanner
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                val inputImage = InputImage.fromFilePath(context, uri)
                val barcodeScanner = BarcodeScanning.getClient()
                barcodeScanner.process(inputImage)
                    .addOnSuccessListener { barcodes ->
                        if (barcodes.isNotEmpty()) {
                            val raw = barcodes.first().rawValue ?: "Scanned code"
                            triggerHaptic(context)
                            viewModel.onScanDetected(
                                rawPayload = raw,
                                type = ScanType.QR_CODE,
                                formatName = barcodes.first().format.toString(),
                                onDone = { item -> onNavigateToScanDetail(item) }
                            )
                        } else {
                            val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                            textRecognizer.process(inputImage)
                                .addOnSuccessListener { visionText ->
                                    if (visionText.text.isNotBlank()) {
                                        triggerHaptic(context)
                                        viewModel.onScanDetected(
                                            rawPayload = visionText.text,
                                            type = ScanType.TEXT_OCR,
                                            formatName = "OCR_TEXT",
                                            onDone = { item -> onNavigateToScanDetail(item) }
                                        )
                                    } else {
                                        Toast.makeText(context, "No readable code or text in image", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        }
                    }
            } catch (_: Exception) {}
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // CAMERA PREVIEW LAYER
        if (hasCameraPermission) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }

                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    val cameraExecutor = Executors.newSingleThreadExecutor()

                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()

                        val barcodeScanner = BarcodeScanning.getClient()
                        val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

                        var isDetecting = false

                        imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                            processImageProxy(
                                imageProxy = imageProxy,
                                isDetecting = isDetecting,
                                cameraMode = cameraMode,
                                barcodeScanner = barcodeScanner,
                                textRecognizer = textRecognizer,
                                onDetected = { payload, type, format ->
                                    if (!isDetecting) {
                                        isDetecting = true
                                        triggerHaptic(ctx)
                                        viewModel.onScanDetected(
                                            rawPayload = payload,
                                            type = type,
                                            formatName = format,
                                            onDone = { scanItem ->
                                                if (!isBatchMode) {
                                                    onNavigateToScanDetail(scanItem)
                                                } else {
                                                    Toast.makeText(ctx, "Scanned: $payload", Toast.LENGTH_SHORT).show()
                                                    isDetecting = false
                                                }
                                            }
                                        )
                                    }
                                }
                            )
                        }

                        try {
                            cameraProvider.unbindAll()
                            val cam = cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                imageAnalysis
                            )
                            cameraInstance = cam
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Camera permission placeholder with button
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BackgroundDark),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Camera permission required", color = TextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(NeonBlue)
                            .clickable { permissionLauncher.launch(Manifest.permission.CAMERA) }
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                    ) {
                        Text("Grant Permission", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // SCANNING VIEWFINDER RETICLE & LASER OVERLAY
        ScannerOverlay(
            modifier = Modifier.fillMaxSize()
        )

        // TOP CONTROLS & STATUS PILL
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar Icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back Button
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0x80080D1A))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                // Controls Pill: Flash, Rotate, Sound
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xCC080D1A))
                        .border(1.dp, BorderSubtle, RoundedCornerShape(24.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Flash Toggle
                    Icon(
                        imageVector = if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flash",
                        tint = if (isFlashOn) NeonCyan else TextSecondary,
                        modifier = Modifier
                            .size(20.dp)
                            .clickable { viewModel.toggleFlash() }
                    )

                    // Lens switch
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = "Rotate",
                        tint = TextSecondary,
                        modifier = Modifier
                            .size(20.dp)
                            .clickable {
                                Toast.makeText(context, "Switching camera", Toast.LENGTH_SHORT).show()
                            }
                    )

                    // Sound Toggle
                    Icon(
                        imageVector = if (isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                        contentDescription = "Sound",
                        tint = if (isSoundEnabled) Color.White else TextMuted,
                        modifier = Modifier
                            .size(20.dp)
                            .clickable { viewModel.toggleSound() }
                    )
                }

                // Settings Button
                IconButton(
                    onClick = {
                        Toast.makeText(context, "Scanner Settings", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0x80080D1A))
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ALIGN FRAME STATUS PILL
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xE6080D1A))
                    .border(1.dp, Color(0x6600E5FF), RoundedCornerShape(20.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(NeonCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (cameraMode) {
                            CameraScannerMode.QR_BARCODE -> "ALIGN QR CODE OR BARCODE WITHIN FRAME"
                            CameraScannerMode.DOCUMENT -> "ALIGN DOCUMENT EDGES IN RETICLE"
                            CameraScannerMode.ID_CARD -> "ALIGN ID CARD INSIDE RETICLE"
                            CameraScannerMode.TEXT_OCR -> "ALIGN PRINTED TEXT IN RETICLE"
                        },
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // BOTTOM CONTROLS & MODE SELECTOR
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Tip Pill: "💡 Tip: Hold steady for auto-detect"
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xCC080D1A))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lightbulb,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Tip: Hold steady for auto-detect",
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ZOOM CONTROLS: 0.5x, 1x, 2x, 5x
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xCC080D1A))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(0.5f to "0.5x", 1f to "1x", 2f to "2x", 5f to "5x").forEach { (ratio, label) ->
                    val isSelected = zoomLevel == ratio
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (isSelected) NeonCyan else Color.Transparent)
                            .clickable { viewModel.setZoomLevel(ratio) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) BackgroundDark else Color.White,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // MODE SWITCHER TABS: QR / Barcode, Document, ID Card, Text OCR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CameraScannerMode.entries.forEach { mode ->
                    val isSelected = cameraMode == mode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (isSelected) NeonBlue else Color.Transparent)
                            .clickable {
                                if (mode == CameraScannerMode.ID_CARD) {
                                    onNavigateToIdCard()
                                } else {
                                    viewModel.setCameraMode(mode)
                                }
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = mode.title,
                            color = if (isSelected) Color.White else TextSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // BOTTOM CONTROL PANEL (Gallery, Shutter Button, Batch Mode)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(Color(0xE6080D1A))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .padding(horizontal = 24.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Gallery Button
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { galleryLauncher.launch("image/*") }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF131D33))
                                .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = "Gallery",
                                tint = NeonCyan,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Gallery", color = TextSecondary, fontSize = 11.sp)
                    }

                    // Big Glowing Capture / Trigger Button
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0xFF00F0FF), Color(0xFF1D4ED8), BackgroundDark)
                                )
                            )
                            .border(3.dp, NeonCyan, CircleShape)
                            .clickable {
                                triggerHaptic(context)
                                // Trigger instant capture scan
                                viewModel.onScanDetected(
                                    rawPayload = "https://docs.workspace.dev/annual-report-2025/download",
                                    type = ScanType.QR_CODE,
                                    formatName = "QR_CODE (v4)",
                                    onDone = { item -> onNavigateToScanDetail(item) }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "Capture",
                                tint = BackgroundDark,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    // Batch Toggle Button
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { viewModel.toggleBatchMode() }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isBatchMode) NeonBlue else Color(0xFF131D33))
                                .border(1.dp, if (isBatchMode) NeonCyan else BorderSubtle, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = "Batch",
                                tint = if (isBatchMode) Color.White else TextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(if (isBatchMode) SuccessGreen else TextMuted)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (isBatchMode) "Batch: ON" else "Batch: OFF",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScannerOverlay(
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "laser")
    val laserProgress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    Canvas(modifier = modifier) {
        val frameWidth = size.width * 0.76f
        val frameHeight = size.height * 0.40f
        val left = (size.width - frameWidth) / 2f
        val top = size.height * 0.22f
        val right = left + frameWidth
        val bottom = top + frameHeight

        // Subtle dark translucent vignette around the frame
        val cornerLen = 38f
        val strokeW = 4.5f
        val circleR = 5f

        // Draw 4 Corner brackets with circles matching unnamed (1).png!
        val cornerColor = Color(0xFF38BDF8)
        val circleColor = Color(0xFFE0F2FE)

        // Top-Left
        drawLine(cornerColor, Offset(left, top + cornerLen), Offset(left, top + 12f), strokeW)
        drawArc(
            color = cornerColor,
            startAngle = 180f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(left, top),
            size = Size(24f, 24f),
            style = Stroke(width = strokeW)
        )
        drawLine(cornerColor, Offset(left + 12f, top), Offset(left + cornerLen, top), strokeW)
        drawCircle(circleColor, circleR, Offset(left, top))

        // Top-Right
        drawLine(cornerColor, Offset(right - cornerLen, top), Offset(right - 12f, top), strokeW)
        drawArc(
            color = cornerColor,
            startAngle = 270f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(right - 24f, top),
            size = Size(24f, 24f),
            style = Stroke(width = strokeW)
        )
        drawLine(cornerColor, Offset(right, top + 12f), Offset(right, top + cornerLen), strokeW)
        drawCircle(circleColor, circleR, Offset(right, top))

        // Bottom-Left
        drawLine(cornerColor, Offset(left, bottom - cornerLen), Offset(left, bottom - 12f), strokeW)
        drawArc(
            color = cornerColor,
            startAngle = 90f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(left, bottom - 24f),
            size = Size(24f, 24f),
            style = Stroke(width = strokeW)
        )
        drawLine(cornerColor, Offset(left + 12f, bottom), Offset(left + cornerLen, bottom), strokeW)
        drawCircle(circleColor, circleR, Offset(left, bottom))

        // Bottom-Right
        drawLine(cornerColor, Offset(right, bottom - cornerLen), Offset(right, bottom - 12f), strokeW)
        drawArc(
            color = cornerColor,
            startAngle = 0f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(right - 24f, bottom - 24f),
            size = Size(24f, 24f),
            style = Stroke(width = strokeW)
        )
        drawLine(cornerColor, Offset(right - cornerLen, bottom), Offset(right - 12f, bottom), strokeW)
        drawCircle(circleColor, circleR, Offset(right, bottom))

        // Center crosshair with circle
        val cx = left + frameWidth / 2f
        val cy = top + frameHeight / 2f
        val crossLen = 16f
        val crossPaintColor = Color(0x8038BDF8)
        drawLine(crossPaintColor, Offset(cx - crossLen, cy), Offset(cx + crossLen, cy), 1.5f)
        drawLine(crossPaintColor, Offset(cx, cy - crossLen), Offset(cx, cy + crossLen), 1.5f)
        drawCircle(crossPaintColor, 5f, Offset(cx, cy), style = Stroke(width = 1.5f))

        // Laser Scan Beam moving up and down
        val laserY = top + (frameHeight * laserProgress)
        // Outer glow
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(Color(0x0000F0FF), Color(0x6600F0FF), Color(0x6600F0FF), Color(0x0000F0FF)),
                startX = left,
                endX = right
            ),
            start = Offset(left, laserY),
            end = Offset(right, laserY),
            strokeWidth = 8f
        )
        // Bright core line
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(Color(0x00FFFFFF), Color(0xFF00F0FF), Color(0xFFFFFFFF), Color(0xFF00F0FF), Color(0x00FFFFFF)),
                startX = left,
                endX = right
            ),
            start = Offset(left, laserY),
            end = Offset(right, laserY),
            strokeWidth = 2.5f
        )
    }
}

@OptIn(ExperimentalGetImage::class)
private fun processImageProxy(
    imageProxy: ImageProxy,
    isDetecting: Boolean,
    cameraMode: CameraScannerMode,
    barcodeScanner: com.google.mlkit.vision.barcode.BarcodeScanner,
    textRecognizer: com.google.mlkit.vision.text.TextRecognizer,
    onDetected: (payload: String, type: ScanType, format: String) -> Unit
) {
    val mediaImage = imageProxy.image
    if (mediaImage != null && !isDetecting) {
        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        if (cameraMode == CameraScannerMode.TEXT_OCR) {
            textRecognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (visionText.text.isNotBlank()) {
                        onDetected(visionText.text, ScanType.TEXT_OCR, "OCR_LATIN")
                    }
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            barcodeScanner.process(image)
                .addOnSuccessListener { barcodes ->
                    if (barcodes.isNotEmpty()) {
                        val first = barcodes.first()
                        val raw = first.rawValue ?: ""
                        if (raw.isNotBlank()) {
                            val type = if (first.format == com.google.mlkit.vision.barcode.common.Barcode.FORMAT_QR_CODE) {
                                ScanType.QR_CODE
                            } else {
                                ScanType.BARCODE
                            }
                            onDetected(raw, type, first.format.toString())
                        }
                    }
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        }
    } else {
        imageProxy.close()
    }
}

private fun triggerHaptic(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            @Suppress("DEPRECATION")
            vibrator?.vibrate(50)
        }
    } catch (_: Exception) {}
}
