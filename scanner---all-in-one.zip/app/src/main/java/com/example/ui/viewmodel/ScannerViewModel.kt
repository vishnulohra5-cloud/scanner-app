package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ScanItem
import com.example.data.model.ScanType
import com.example.data.repository.ScanRepository
import com.example.utils.PdfGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

enum class CameraScannerMode(val title: String) {
    QR_BARCODE("QR / Barcode"),
    DOCUMENT("Document"),
    ID_CARD("ID Card"),
    TEXT_OCR("Text OCR")
}

data class IdCardState(
    val currentStep: Int = 1, // 1 = Front Side, 2 = Back Side, 3 = Stitched Ready
    val idType: String = "Driver License",
    val autoCaptureSteady: Boolean = true,
    val showGrid: Boolean = false,
    val frontBitmap: Bitmap? = null,
    val backBitmap: Bitmap? = null,
    val stitchedPdfFile: File? = null,
    val isProcessing: Boolean = false
)

class ScannerViewModel(
    private val repository: ScanRepository
) : ViewModel() {

    // Search and Category Filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Scanner Camera Controls
    private val _cameraMode = MutableStateFlow(CameraScannerMode.QR_BARCODE)
    val cameraMode: StateFlow<CameraScannerMode> = _cameraMode.asStateFlow()

    private val _isFlashOn = MutableStateFlow(false)
    val isFlashOn: StateFlow<Boolean> = _isFlashOn.asStateFlow()

    private val _isSoundEnabled = MutableStateFlow(true)
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled.asStateFlow()

    private val _zoomLevel = MutableStateFlow(1f)
    val zoomLevel: StateFlow<Float> = _zoomLevel.asStateFlow()

    private val _isBatchMode = MutableStateFlow(false)
    val isBatchMode: StateFlow<Boolean> = _isBatchMode.asStateFlow()

    // ID Card Scanner State
    private val _idCardState = MutableStateFlow(IdCardState())
    val idCardState: StateFlow<IdCardState> = _idCardState.asStateFlow()

    // Active Scanned Payload for ScanDetailsScreen
    private val _activeScan = MutableStateFlow<ScanItem?>(null)
    val activeScan: StateFlow<ScanItem?> = _activeScan.asStateFlow()

    // App Lock State (Biometric)
    private val _isAppLocked = MutableStateFlow(false)
    val isAppLocked: StateFlow<Boolean> = _isAppLocked.asStateFlow()

    private val _isBiometricEnabled = MutableStateFlow(false)
    val isBiometricEnabled: StateFlow<Boolean> = _isBiometricEnabled.asStateFlow()

    // Reactive Scans Stream based on Search & Category
    val scans: StateFlow<List<ScanItem>> = combine(
        repository.allScans,
        _searchQuery,
        _selectedCategory
    ) { allScans, query, category ->
        var filtered = allScans
        if (category == "Documents") {
            filtered = filtered.filter { it.type == ScanType.DOCUMENT || it.type == ScanType.ID_CARD }
        } else if (category == "QR/Barcode") {
            filtered = filtered.filter { it.type == ScanType.QR_CODE || it.type == ScanType.BARCODE }
        }

        if (query.isNotBlank()) {
            filtered = filtered.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.payload.contains(query, ignoreCase = true)
            }
        }
        filtered
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentScans: StateFlow<List<ScanItem>> = repository.recentScans.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favoriteScans: StateFlow<List<ScanItem>> = repository.favoriteScans.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setCameraMode(mode: CameraScannerMode) {
        _cameraMode.value = mode
    }

    fun toggleFlash() {
        _isFlashOn.value = !_isFlashOn.value
    }

    fun toggleSound() {
        _isSoundEnabled.value = !_isSoundEnabled.value
    }

    fun setZoomLevel(zoom: Float) {
        _zoomLevel.value = zoom
    }

    fun toggleBatchMode() {
        _isBatchMode.value = !_isBatchMode.value
    }

    fun setActiveScan(scanItem: ScanItem?) {
        _activeScan.value = scanItem
    }

    fun toggleFavorite(scanItem: ScanItem) {
        viewModelScope.launch {
            repository.toggleFavorite(scanItem.id, scanItem.isFavorite)
            if (_activeScan.value?.id == scanItem.id) {
                _activeScan.value = _activeScan.value?.copy(isFavorite = !scanItem.isFavorite)
            }
        }
    }

    fun updateNote(scanId: Long, note: String) {
        viewModelScope.launch {
            repository.updateNote(scanId, note)
            if (_activeScan.value?.id == scanId) {
                _activeScan.value = _activeScan.value?.copy(note = note)
            }
        }
    }

    fun deleteScan(scanId: Long) {
        viewModelScope.launch {
            repository.deleteScanById(scanId)
            if (_activeScan.value?.id == scanId) {
                _activeScan.value = null
            }
        }
    }

    fun onScanDetected(
        rawPayload: String,
        type: ScanType = ScanType.QR_CODE,
        formatName: String = "QR_CODE",
        onDone: (ScanItem) -> Unit
    ) {
        viewModelScope.launch {
            val isUrl = rawPayload.startsWith("http://") || rawPayload.startsWith("https://")
            val isWifi = rawPayload.startsWith("WIFI:")
            val title = when {
                isUrl -> rawPayload.substringAfter("://").substringBefore("/").ifEmpty { "Website URL" }
                isWifi -> "WiFi: " + rawPayload.substringAfter("S:").substringBefore(";")
                type == ScanType.BARCODE -> "Product Barcode $rawPayload"
                type == ScanType.TEXT_OCR -> "OCR: " + rawPayload.take(24).trim()
                else -> "Scan Record " + rawPayload.take(20)
            }

            val formatSpec = if (type == ScanType.QR_CODE) {
                "Format: QR_CODE (Version 4, 33x33) ECC: Quartile"
            } else {
                "Format: $formatName"
            }

            val security = if (isUrl) {
                "Safe Link Detected • Zero threats"
            } else if (isWifi) {
                "WPA/WPA2 Secured Network"
            } else {
                "On-Device Verified Safe"
            }

            val newItem = ScanItem(
                title = title,
                type = type,
                payload = rawPayload,
                formatInfo = formatSpec,
                securityStatus = security,
                metaDetail = "Just now • High confidence",
                timestamp = System.currentTimeMillis()
            )

            val newId = repository.insertScan(newItem)
            val savedItem = newItem.copy(id = newId)
            _activeScan.value = savedItem
            onDone(savedItem)
        }
    }

    // ID Card Scanner actions
    fun setIdCardType(type: String) {
        _idCardState.value = _idCardState.value.copy(idType = type)
    }

    fun toggleAutoCaptureSteady() {
        _idCardState.value = _idCardState.value.copy(
            autoCaptureSteady = !_idCardState.value.autoCaptureSteady
        )
    }

    fun toggleGrid() {
        _idCardState.value = _idCardState.value.copy(
            showGrid = !_idCardState.value.showGrid
        )
    }

    fun captureIdCardSide(bitmap: Bitmap) {
        val current = _idCardState.value
        if (current.currentStep == 1) {
            _idCardState.value = current.copy(
                frontBitmap = bitmap,
                currentStep = 2
            )
        } else if (current.currentStep == 2) {
            _idCardState.value = current.copy(
                backBitmap = bitmap,
                currentStep = 3
            )
        }
    }

    fun resetIdCardScan() {
        _idCardState.value = IdCardState()
    }

    fun stitchIdCard(context: Context, onComplete: (File?) -> Unit) {
        val current = _idCardState.value
        viewModelScope.launch {
            val file = PdfGenerator.generateIdCardStitchedPdf(
                context = context,
                frontBitmap = current.frontBitmap,
                backBitmap = current.backBitmap,
                idType = current.idType
            )
            _idCardState.value = current.copy(stitchedPdfFile = file)

            // Also record in database
            if (file != null) {
                val item = ScanItem(
                    title = "${current.idType} - 2 Sided Stitch.pdf",
                    type = ScanType.ID_CARD,
                    payload = "Digitized 2-sided identity card: ${file.absolutePath}",
                    formatInfo = "PDF 300 DPI A4 Sheet",
                    securityStatus = "On-Device Secure Storage",
                    metaDetail = "Just now • 2-Sided Stitched",
                    filePath = file.absolutePath
                )
                val id = repository.insertScan(item)
                _activeScan.value = item.copy(id = id)
            }
            onComplete(file)
        }
    }

    fun unlockApp() {
        _isAppLocked.value = false
    }

    fun lockApp() {
        if (_isBiometricEnabled.value) {
            _isAppLocked.value = true
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        _isBiometricEnabled.value = enabled
    }
}

class ScannerViewModelFactory(private val repository: ScanRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ScannerViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ScannerViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
