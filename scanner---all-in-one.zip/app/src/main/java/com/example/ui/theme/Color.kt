package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Dark Cyberpunk / Modern Vision Scanner Palette
val BackgroundDark = Color(0xFF060A13)
val BackgroundDarkSecondary = Color(0xFF0B1120)
val SurfaceDark = Color(0xFF0F172A)
val SurfaceCard = Color(0xFF111C33)
val SurfaceCardGlass = Color(0xCC0E172C)
val SurfaceElevated = Color(0xFF172341)

// Borders & Dividers
val BorderSubtle = Color(0xFF1E293B)
val BorderAccent = Color(0xFF2A3C63)
val BorderGlow = Color(0x4D00E5FF)

// Neon & Core Brand Accents
val NeonCyan = Color(0xFF00E5FF)
val NeonBlue = Color(0xFF2563EB)
val ElectricBlue = Color(0xFF3B82F6)
val BrightCyan = Color(0xFF38BDF8)
val LaserCyan = Color(0xFF00F0FF)

// Functional Semantic Colors
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenDark = Color(0xFF064E3B)
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)

// Typography
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Badges & Highlights
val BadgeDocBg = Color(0xFF1E3A8A)
val BadgeWifiBg = Color(0xFF0369A1)
val BadgeBarcodeBg = Color(0xFF065F46)
val BadgeAiBg = Color(0xFF4338CA)

// Gradients
val NeonGlowGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF00E5FF), Color(0xFF2563EB))
)

val LaserGradient = Brush.horizontalGradient(
    colors = listOf(Color(0x0000E5FF), Color(0xFF00F0FF), Color(0xFFFFFFFF), Color(0xFF00F0FF), Color(0x0000E5FF))
)

val CardGlowBorder = Brush.verticalGradient(
    colors = listOf(Color(0x6600E5FF), Color(0x1A2563EB), Color(0x0D00E5FF))
)
