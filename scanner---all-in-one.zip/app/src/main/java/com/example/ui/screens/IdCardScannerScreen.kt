package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ScanItem
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ScannerViewModel

@Composable
fun IdCardScannerScreen(
    viewModel: ScannerViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToScanDetail: (ScanItem) -> Unit
) {
    val context = LocalContext.current
    val idCardState by viewModel.idCardState.collectAsStateWithLifecycle()
    val isFlashOn by viewModel.isFlashOn.collectAsStateWithLifecycle()

    var showFormatDropdown by remember { mutableStateOf(false) }
    var selectedSheetFormat by remember { mutableStateOf("A4 Sheet") }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            // Generate placeholder bitmap representation
            val mockBitmap = createMockCardBitmap(
                label = if (idCardState.currentStep == 1) "Front Side" else "Back Side",
                subtext = idCardState.idType
            )
            viewModel.captureIdCardSide(mockBitmap)
            triggerHaptic(context)
            Toast.makeText(context, "Imported card successfully", Toast.LENGTH_SHORT).show()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. TOP BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(SuccessGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ID Card Scanner",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                    }
                    Text(
                        text = "AUTO 2-SIDED STITCH",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BrightCyan,
                            letterSpacing = 0.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = { viewModel.toggleFlash() },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(SurfaceCard)
                    ) {
                        Icon(
                            imageVector = if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "Flash",
                            tint = if (isFlashOn) NeonCyan else TextSecondary
                        )
                    }

                    IconButton(
                        onClick = {
                            Toast.makeText(
                                context,
                                "Place ID card inside the dashed rectangle. Align both front and back sides.",
                                Toast.LENGTH_LONG
                            ).show()
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(SurfaceCard)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Info",
                            tint = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2. STEP-BY-STEP FLOW INDICATOR: ① Front Side -> ② Back Side
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Step 1: Front Side Card
                val isStep1Active = idCardState.currentStep == 1
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isStep1Active) Color(0xFF1E3A8A) else SurfaceCard)
                        .border(
                            1.dp,
                            if (isStep1Active) NeonBlue else BorderSubtle,
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(if (isStep1Active) Color.White else SurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "1",
                                color = if (isStep1Active) NeonBlue else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Front Side",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (idCardState.frontBitmap != null) "Captured" else "Active Framing",
                                color = if (isStep1Active) BrightCyan else TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )

                // Step 2: Back Side Card
                val isStep2Active = idCardState.currentStep == 2
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isStep2Active) Color(0xFF1E3A8A) else SurfaceCard)
                        .border(
                            1.dp,
                            if (isStep2Active) NeonBlue else BorderSubtle,
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(if (isStep2Active) Color.White else SurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "2",
                                color = if (isStep2Active) NeonBlue else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Back Side",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (idCardState.backBitmap != null) "Captured" else "Pending",
                                color = if (isStep2Active) BrightCyan else TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3. ID TYPE SELECTORS: Driver License / National ID / PAN / Aadhaar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isDriver = idCardState.idType == "Driver License"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isDriver) NeonBlue else SurfaceCard)
                        .border(1.dp, if (isDriver) NeonCyan else BorderSubtle, RoundedCornerShape(12.dp))
                        .clickable { viewModel.setIdCardType("Driver License") }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = if (isDriver) Color.White else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Driver License",
                            color = if (isDriver) Color.White else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isDriver) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                val isNationalId = idCardState.idType != "Driver License"
                Box(
                    modifier = Modifier
                        .weight(1.3f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isNationalId) NeonBlue else SurfaceCard)
                        .border(1.dp, if (isNationalId) NeonCyan else BorderSubtle, RoundedCornerShape(12.dp))
                        .clickable { viewModel.setIdCardType("National ID / PAN / Aadhaar") }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = if (isNationalId) Color.White else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "National ID / PAN / Aadhaar",
                            color = if (isNationalId) Color.White else TextSecondary,
                            fontSize = 11.5.sp,
                            fontWeight = if (isNationalId) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 4. PRIVACY DISCLAIMER TEXT
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "On-device digitization utility • Not affiliated with any government agency",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextMuted,
                        fontSize = 10.5.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 5. FRAMING VIEWFINDER CANVAS (Dashed rectangle frame)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0A101D)),
                contentAlignment = Alignment.Center
            ) {
                // Dashed frame drawing
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cardW = size.width * 0.88f
                    val cardH = cardW * 0.63f // Standard ID-1 card aspect ratio (85.6mm x 53.98mm)
                    val left = (size.width - cardW) / 2f
                    val top = (size.height - cardH) / 2f

                    // Grid overlay if enabled
                    if (idCardState.showGrid) {
                        val gridPaintColor = Color(0x2238BDF8)
                        for (i in 1..3) {
                            val gx = left + (cardW / 4f) * i
                            drawLine(gridPaintColor, Offset(gx, top), Offset(gx, top + cardH), 1f)
                        }
                        for (i in 1..3) {
                            val gy = top + (cardH / 4f) * i
                            drawLine(gridPaintColor, Offset(left, gy), Offset(left + cardW, gy), 1f)
                        }
                    }

                    // Dashed rounded border
                    drawRoundRect(
                        color = Color(0xFF38BDF8),
                        topLeft = Offset(left, top),
                        size = Size(cardW, cardH),
                        cornerRadius = CornerRadius(16f, 16f),
                        style = Stroke(
                            width = 2.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f), 0f)
                        )
                    )
                }

                // Place ID Inside Rectangle Tip Pill
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 24.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xCC080D1A))
                        .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (idCardState.currentStep == 1) {
                                "Place ID Front inside rectangle. Avoid glare."
                            } else {
                                "Flip over and place ID Back inside rectangle."
                            },
                            color = TextPrimary,
                            fontSize = 11.5.sp
                        )
                    }
                }

                // "Smart Angle Flatten Active" Corner Badge matching screenshot
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 20.dp, end = 20.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xCC062535))
                        .border(1.dp, Color(0x6600E5FF), RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "Smart Angle",
                                color = NeonCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Flatten Active",
                                color = NeonCyan,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 6. BOTTOM STATUS CARD ("Front Captured 300 DPI - Flip card over...")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Card Thumbnail with 1/2 badge
                        Box(
                            modifier = Modifier
                                .size(50.dp, 34.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, NeonCyan, RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (idCardState.currentStep >= 2) "1/2" else "1/2",
                                color = BrightCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (idCardState.frontBitmap != null) "Front Captured" else "Front Pending",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0x3310B981))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "300 DPI",
                                        color = SuccessGreen,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (idCardState.frontBitmap != null && idCardState.backBitmap == null) {
                                    "Flip card over to frame back side"
                                } else if (idCardState.backBitmap != null) {
                                    "Both sides captured • Ready to stitch PDF"
                                } else {
                                    "Tap capture when front is framed"
                                },
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // A4 Sheet Dropdown Selector
                    Box {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(SurfaceElevated)
                                .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                                .clickable { showFormatDropdown = true }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = selectedSheetFormat,
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(text = " ▾", color = TextSecondary, fontSize = 11.sp)
                            }
                        }

                        DropdownMenu(
                            expanded = showFormatDropdown,
                            onDismissRequest = { showFormatDropdown = false },
                            modifier = Modifier.background(SurfaceDark)
                        ) {
                            listOf("A4 Sheet", "US Letter", "Single Card (Fit)").forEach { format ->
                                DropdownMenuItem(
                                    text = { Text(format, color = TextPrimary) },
                                    onClick = {
                                        selectedSheetFormat = format
                                        showFormatDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 7. AUTO-CAPTURE ON STEADY TOGGLE SWITCH
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF0C1425))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Auto-Capture on Steady",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Switch(
                        checked = idCardState.autoCaptureSteady,
                        onCheckedChange = { viewModel.toggleAutoCaptureSteady() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NeonBlue,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = SurfaceElevated
                        ),
                        modifier = Modifier.size(40.dp, 24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 8. BOTTOM CONTROLS: Import, Center Big Capture, Grid Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Import Gallery Button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { importLauncher.launch("image/*") }
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(SurfaceCard)
                            .border(1.dp, BorderSubtle, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = "Import",
                            tint = TextSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Import", color = TextSecondary, fontSize = 11.sp)
                }

                // Center Big Capture Button with state ("TAP FRONT" -> "TAP BACK" -> "GENERATE PDF")
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0xFF00F0FF), Color(0xFF1D4ED8), BackgroundDark)
                                )
                            )
                            .border(3.dp, NeonCyan, CircleShape)
                            .clickable {
                                triggerHaptic(context)
                                if (idCardState.currentStep == 1) {
                                    val frontBmp = createMockCardBitmap("Front Side", idCardState.idType)
                                    viewModel.captureIdCardSide(frontBmp)
                                    Toast.makeText(context, "Front captured! Now flip card over to frame back.", Toast.LENGTH_SHORT).show()
                                } else if (idCardState.currentStep == 2) {
                                    val backBmp = createMockCardBitmap("Back Side", idCardState.idType)
                                    viewModel.captureIdCardSide(backBmp)
                                    Toast.makeText(context, "Back captured! Ready to stitch 2-sided PDF.", Toast.LENGTH_SHORT).show()
                                } else {
                                    // Generate 2-sided PDF
                                    viewModel.stitchIdCard(context) { file ->
                                        if (file != null) {
                                            viewModel.activeScan.value?.let { onNavigateToScanDetail(it) }
                                        } else {
                                            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (idCardState.currentStep == 3) {
                                    Icons.Default.PictureAsPdf
                                } else {
                                    Icons.Default.CreditCard
                                },
                                contentDescription = "Capture",
                                tint = BackgroundDark,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Pill label under button: TAP FRONT / TAP BACK / STITCH PDF
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1E293B))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = when (idCardState.currentStep) {
                                1 -> "TAP FRONT"
                                2 -> "TAP BACK"
                                else -> "STITCH PDF"
                            },
                            color = BrightCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Grid Toggle Button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { viewModel.toggleGrid() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(if (idCardState.showGrid) NeonBlue else SurfaceCard)
                            .border(1.dp, if (idCardState.showGrid) NeonCyan else BorderSubtle, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GridOn,
                            contentDescription = "Grid",
                            tint = if (idCardState.showGrid) Color.White else TextSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Grid", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun createMockCardBitmap(label: String, subtext: String): Bitmap {
    val bitmap = Bitmap.createBitmap(600, 380, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(AndroidColor.parseColor("#0F172A"))

    val cardPaint = Paint().apply {
        color = AndroidColor.parseColor("#1E293B")
        isAntiAlias = true
    }
    canvas.drawRoundRect(20f, 20f, 580f, 360f, 20f, 20f, cardPaint)

    val borderPaint = Paint().apply {
        color = AndroidColor.parseColor("#00E5FF")
        style = Paint.Style.STROKE
        strokeWidth = 3f
        isAntiAlias = true
    }
    canvas.drawRoundRect(20f, 20f, 580f, 360f, 20f, 20f, borderPaint)

    val textPaint = Paint().apply {
        color = AndroidColor.WHITE
        textSize = 28f
        isFakeBoldText = true
        isAntiAlias = true
    }
    canvas.drawText("DIGITIZED: $label", 50f, 80f, textPaint)

    val subPaint = Paint().apply {
        color = AndroidColor.parseColor("#94A3B8")
        textSize = 18f
        isAntiAlias = true
    }
    canvas.drawText(subtext, 50f, 120f, subPaint)
    canvas.drawText("On-device secure 300 DPI capture", 50f, 160f, subPaint)

    // Draw simulated photo box
    val photoPaint = Paint().apply { color = AndroidColor.parseColor("#334155") }
    canvas.drawRoundRect(400f, 60f, 540f, 220f, 12f, 12f, photoPaint)

    return bitmap
}

private fun triggerHaptic(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            @Suppress("DEPRECATION")
            vibrator?.vibrate(50)
        }
    } catch (_: Exception) {}
}
