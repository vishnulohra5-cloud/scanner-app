package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.database.AppDatabase
import com.example.data.model.ScanItem
import com.example.data.repository.ScanRepository
import com.example.ui.screens.CameraScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.GenerateCodeScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IdCardScannerScreen
import com.example.ui.screens.PdfToolsScreen
import com.example.ui.screens.ScanDetailsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ScannerTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CameraScannerMode
import com.example.ui.viewmodel.ScannerViewModel
import com.example.ui.viewmodel.ScannerViewModelFactory
import com.example.utils.BiometricAuthHelper

class MainActivity : FragmentActivity() {

    private lateinit var viewModel: ScannerViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Database & Repository
        val database = AppDatabase.getDatabase(this)
        val repository = ScanRepository(database.scanDao())
        viewModel = ViewModelProvider(this, ScannerViewModelFactory(repository))[ScannerViewModel::class.java]

        setContent {
            ScannerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = BackgroundDark
                ) {
                    ScannerApp(
                        activity = this,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

sealed class ScreenRoute {
    data object Home : ScreenRoute()
    data class Camera(val mode: CameraScannerMode = CameraScannerMode.QR_BARCODE) : ScreenRoute()
    data object IdCard : ScreenRoute()
    data class ScanDetails(val scanItem: ScanItem) : ScreenRoute()
    data class GenerateCode(val initialPayload: String = "") : ScreenRoute()
    data object PdfTools : ScreenRoute()
    data object History : ScreenRoute()
    data object Favorites : ScreenRoute()
    data object Settings : ScreenRoute()
}

@Composable
fun ScannerApp(
    activity: FragmentActivity,
    viewModel: ScannerViewModel
) {
    var currentScreen by remember { mutableStateOf<ScreenRoute>(ScreenRoute.Home) }
    var activeBottomTab by remember { mutableStateOf("home") }

    val isAppLocked by viewModel.isAppLocked.collectAsStateWithLifecycle()
    val isBiometricEnabled by viewModel.isBiometricEnabled.collectAsStateWithLifecycle()
    val activeScan by viewModel.activeScan.collectAsStateWithLifecycle()

    // App Lock Overlay
    if (isAppLocked && isBiometricEnabled) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundDark),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(32.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF131D33)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = NeonCyan,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Scanner Locked",
                    style = MaterialTheme.typography.titleLarge.copy(color = TextPrimary)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Biometric authentication required to view confidential documents.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(28.dp))

                Button(
                    onClick = {
                        BiometricAuthHelper.authenticate(
                            activity = activity,
                            onSuccess = { viewModel.unlockApp() },
                            onError = { /* Keep locked */ }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonBlue),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null)
                    Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                    Text("Unlock with Biometrics")
                }
            }
        }
        return
    }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "navigation"
    ) { screen ->
        when (screen) {
            is ScreenRoute.Home -> {
                activeBottomTab = "home"
                HomeScreen(
                    viewModel = viewModel,
                    activeTab = "home",
                    onNavigateToCamera = { mode -> currentScreen = ScreenRoute.Camera(mode) },
                    onNavigateToIdCard = { currentScreen = ScreenRoute.IdCard },
                    onNavigateToGenerate = { currentScreen = ScreenRoute.GenerateCode() },
                    onNavigateToPdfTools = { currentScreen = ScreenRoute.PdfTools },
                    onNavigateToScanDetail = { scan -> currentScreen = ScreenRoute.ScanDetails(scan) },
                    onNavigateToTab = { tab ->
                        activeBottomTab = tab
                        currentScreen = when (tab) {
                            "history" -> ScreenRoute.History
                            "favorites" -> ScreenRoute.Favorites
                            "settings" -> ScreenRoute.Settings
                            else -> ScreenRoute.Home
                        }
                    }
                )
            }

            is ScreenRoute.Camera -> {
                CameraScreen(
                    viewModel = viewModel,
                    initialMode = screen.mode,
                    onNavigateBack = { currentScreen = ScreenRoute.Home },
                    onNavigateToScanDetail = { scan -> currentScreen = ScreenRoute.ScanDetails(scan) },
                    onNavigateToIdCard = { currentScreen = ScreenRoute.IdCard }
                )
            }

            is ScreenRoute.IdCard -> {
                IdCardScannerScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = ScreenRoute.Home },
                    onNavigateToScanDetail = { scan -> currentScreen = ScreenRoute.ScanDetails(scan) }
                )
            }

            is ScreenRoute.ScanDetails -> {
                ScanDetailsScreen(
                    viewModel = viewModel,
                    scanItem = screen.scanItem,
                    onNavigateBack = { currentScreen = ScreenRoute.Home },
                    onScanNext = { currentScreen = ScreenRoute.Camera() },
                    onNavigateToGenerateWithText = { payload ->
                        currentScreen = ScreenRoute.GenerateCode(payload)
                    }
                )
            }

            is ScreenRoute.GenerateCode -> {
                GenerateCodeScreen(
                    viewModel = viewModel,
                    initialText = screen.initialPayload,
                    onNavigateBack = { currentScreen = ScreenRoute.Home }
                )
            }

            is ScreenRoute.PdfTools -> {
                PdfToolsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = ScreenRoute.Home },
                    onNavigateToIdCard = { currentScreen = ScreenRoute.IdCard }
                )
            }

            is ScreenRoute.History -> {
                activeBottomTab = "history"
                HistoryScreen(
                    viewModel = viewModel,
                    onNavigateToScanDetail = { scan -> currentScreen = ScreenRoute.ScanDetails(scan) },
                    onNavigateToTab = { tab ->
                        activeBottomTab = tab
                        currentScreen = when (tab) {
                            "home" -> ScreenRoute.Home
                            "favorites" -> ScreenRoute.Favorites
                            "settings" -> ScreenRoute.Settings
                            else -> ScreenRoute.History
                        }
                    },
                    onNavigateToCamera = { mode -> currentScreen = ScreenRoute.Camera(mode) }
                )
            }

            is ScreenRoute.Favorites -> {
                activeBottomTab = "favorites"
                FavoritesScreen(
                    viewModel = viewModel,
                    onNavigateToScanDetail = { scan -> currentScreen = ScreenRoute.ScanDetails(scan) },
                    onNavigateToTab = { tab ->
                        activeBottomTab = tab
                        currentScreen = when (tab) {
                            "home" -> ScreenRoute.Home
                            "history" -> ScreenRoute.History
                            "settings" -> ScreenRoute.Settings
                            else -> ScreenRoute.Favorites
                        }
                    },
                    onNavigateToCamera = { mode -> currentScreen = ScreenRoute.Camera(mode) }
                )
            }

            is ScreenRoute.Settings -> {
                activeBottomTab = "settings"
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToTab = { tab ->
                        activeBottomTab = tab
                        currentScreen = when (tab) {
                            "home" -> ScreenRoute.Home
                            "history" -> ScreenRoute.History
                            "favorites" -> ScreenRoute.Favorites
                            else -> ScreenRoute.Settings
                        }
                    },
                    onNavigateToCamera = { mode -> currentScreen = ScreenRoute.Camera(mode) }
                )
            }
        }
    }
}
