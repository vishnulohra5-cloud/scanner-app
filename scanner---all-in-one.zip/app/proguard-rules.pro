# Scanner - All In One ProGuard Rules for Signed .AAB

-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

# Room Database
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# CameraX
-keep class androidx.camera.** { *; }
-dontwarn androidx.camera.**

# Google ML Kit
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**

# Google Play Services & AdMob
-keep class com.google.android.gms.ads.** { *; }
-keep public class com.google.android.gms.ads.initialization.OnInitializationCompleteListener { *; }
-dontwarn com.google.android.gms.**

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

